-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema fe
--

CREATE DATABASE IF NOT EXISTS fe;
USE fe;

--
-- Definition of table `interno`
--

DROP TABLE IF EXISTS `interno`;
CREATE TABLE `interno` (
  `RUT_INT` varchar(15) NOT NULL,
  `NOMBRE_INT` varchar(30) NOT NULL,
  `APELLIDO_INT` varchar(30) NOT NULL,
  `TELEFONO_INT` varchar(10) NOT NULL,
  PRIMARY KEY  (`RUT_INT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interno`
--

/*!40000 ALTER TABLE `interno` DISABLE KEYS */;
INSERT INTO `interno` (`RUT_INT`,`NOMBRE_INT`,`APELLIDO_INT`,`TELEFONO_INT`) VALUES 
 ('15.853.168-2','Juan','Perez','123234');
/*!40000 ALTER TABLE `interno` ENABLE KEYS */;


--
-- Definition of table `kinesiologo`
--

DROP TABLE IF EXISTS `kinesiologo`;
CREATE TABLE `kinesiologo` (
  `RUT_K` varchar(15) NOT NULL,
  `NOMBRE_K` varchar(30) NOT NULL,
  `APELLIDO_K` varchar(30) NOT NULL,
  `TELEFONO_K` varchar(10) NOT NULL,
  PRIMARY KEY  (`RUT_K`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kinesiologo`
--

/*!40000 ALTER TABLE `kinesiologo` DISABLE KEYS */;
INSERT INTO `kinesiologo` (`RUT_K`,`NOMBRE_K`,`APELLIDO_K`,`TELEFONO_K`) VALUES 
 ('15.853.168-2','Kine1','ApKine1','123456');
/*!40000 ALTER TABLE `kinesiologo` ENABLE KEYS */;


--
-- Definition of table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
CREATE TABLE `paciente` (
  `RUT_PAC` varchar(15) NOT NULL,
  `NOMBRE_PAC` varchar(30) NOT NULL,
  `APELLIDO_PAC` varchar(30) NOT NULL,
  `DIRECCION_PAC` varchar(200) default NULL,
  `TELEFONO1_PAC` varchar(10) NOT NULL,
  `TELEFONO2_PAC` varchar(10) default NULL,
  `F_NAC_PAC` date NOT NULL,
  PRIMARY KEY  (`RUT_PAC`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paciente`
--

/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
INSERT INTO `paciente` (`RUT_PAC`,`NOMBRE_PAC`,`APELLIDO_PAC`,`DIRECCION_PAC`,`TELEFONO1_PAC`,`TELEFONO2_PAC`,`F_NAC_PAC`) VALUES 
 ('15.853.168-2','juan','perez','mi casa','123','456','1984-04-12');
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;


--
-- Definition of table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
CREATE TABLE `permiso` (
  `ID_PERMISO` varchar(10) NOT NULL,
  `DESC_PERMISO` varchar(150) NOT NULL,
  `TIPO_PERMISO` int(11) NOT NULL,
  PRIMARY KEY  (`ID_PERMISO`,`TIPO_PERMISO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permiso`
--

/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
INSERT INTO `permiso` (`ID_PERMISO`,`DESC_PERMISO`,`TIPO_PERMISO`) VALUES 
 ('1','lee Paciente',1),
 ('10','lee Informe',2),
 ('100','lee Internista',3),
 ('1000','lee Kinesiologo',4),
 ('10000','lee Usuario',5),
 ('2','agrega Paciente',1),
 ('20','agrega Informe',2),
 ('200','agrega Internista',3),
 ('2000','agrega Kinesiologo',4),
 ('20000','agrega Usuario',5),
 ('3','agrega / modifica Paciente',1),
 ('30','agrega / modifica Informe',2),
 ('300','agrega / modifica Internista',3),
 ('3000','agrega / modifica Kinesiologo',4),
 ('30000','agrega / modifica Usuario',5),
 ('4','agrega / modifica / elimina Paciente',1),
 ('40','agrega / modifica / elimina Informe',2),
 ('400','agrega / modifica / elimina Internista',3),
 ('4000','agrega / modifica / elimina Kinesiologo',4),
 ('40000','agrega / modifica / elimina Usuario',5),
 ('9','no lee Paciente',1),
 ('90','no lee Informe',3),
 ('900','no lee Internista',3),
 ('9000','no lee Kinesiologo',4),
 ('90000','no lee Usuario',5);
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;


--
-- Definition of table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `ID_USUARIO` int(11) NOT NULL,
  `USUARIO` varchar(20) NOT NULL,
  `PASS_USUARIO` varchar(20) NOT NULL,
  `NOMBRE` varchar(150) NOT NULL,
  PRIMARY KEY  (`USUARIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`ID_USUARIO`,`USUARIO`,`PASS_USUARIO`,`NOMBRE`) VALUES 
 (3,'admin','123','Administrador'),
 (2,'fmoore','123','Francisco Moore'),
 (4,'test0','',''),
 (5,'test1','',''),
 (6,'test2','',''),
 (7,'test3','',''),
 (8,'test4','','');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;


--
-- Definition of table `usuario_permiso`
--

DROP TABLE IF EXISTS `usuario_permiso`;
CREATE TABLE `usuario_permiso` (
  `ID_PERMISO` varchar(10) NOT NULL,
  `USUARIO` varchar(20) NOT NULL,
  PRIMARY KEY  (`USUARIO`),
  KEY `FK_USUARIO_PERMISO` (`ID_PERMISO`),
  CONSTRAINT `FK_USUARIO_PERMISO2` FOREIGN KEY (`USUARIO`) REFERENCES `usuario` (`USUARIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario_permiso`
--

/*!40000 ALTER TABLE `usuario_permiso` DISABLE KEYS */;
INSERT INTO `usuario_permiso` (`ID_PERMISO`,`USUARIO`) VALUES 
 ('39444','test1'),
 ('44442','fmoore'),
 ('44444','admin'),
 ('99924','test2'),
 ('99934','test3'),
 ('99944','test4'),
 ('99994','test0');
/*!40000 ALTER TABLE `usuario_permiso` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
